#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import requests

API_BASE = (os.environ.get("WIPAD_API_BASE") or "https://api.wepod.ir").rstrip("/") + "/"
PORT = int(os.environ.get("WIPAD_PORT") or "8089")
SESSION_PATH = os.environ.get("WIPAD_SESSION") or "/var/lib/wipad-api/session.json"
PROXY = (os.environ.get("WIPAD_PROXY") or os.environ.get("BLU_PROXY") or "").strip()
PROXIES = {"http": PROXY, "https": PROXY} if PROXY else None
TIMEOUT = float(os.environ.get("WIPAD_TIMEOUT") or "45")
MULT = float(os.environ.get("WIPAD_AMOUNT_MULTIPLIER") or "1")
UA = (
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
)
CLIENT = os.environ.get("WIPAD_CLIENT_VERSION") or "Wepod_web-5.2.7.1.Pas"
CLIENT_NEW = "Wepod_web-5.2.7.1.Pas"
APP_VERSION = os.environ.get("WIPAD_APP_VERSION") or "Wepod_web-5.2.7.1.Pas"
CLIENT_ISSUER = 210
FLOW_TYPE = 1
TEHRAN = timezone(timedelta(hours=3, minutes=30))
LOCK = threading.RLock()
OWNER_NAME = ""


class BankError(Exception):
    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.status = status


class AuthError(BankError):
    def __init__(self, message: str):
        super().__init__(message, 401)


class BadInput(BankError):
    def __init__(self, message: str):
        super().__init__(message, 400)


def log(message: str) -> None:
    sys.stderr.write(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + " " + message + "\n")
    sys.stderr.flush()


def clip(value: str, size: int = 220) -> str:
    value = " ".join(str(value).split())
    return value if len(value) <= size else value[:size] + "..."


def digits(value) -> str:
    if value is None:
        return ""
    text = str(value)
    text = text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    return re.sub(r"\D", "", text)


def norm_phone(value: str) -> str:
    number = digits(value)
    if number.startswith("0098"):
        number = number[4:]
    if number.startswith("98") and len(number) == 12:
        number = number[2:]
    if len(number) == 10 and number.startswith("9"):
        number = "0" + number
    return number


def mask_phone(value: str) -> str:
    number = digits(value)
    if len(number) < 7:
        return number
    return number[:4] + "***" + number[-3:]


def num(value) -> float:
    if value is None or isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, dict):
        return 0.0
    text = str(value).translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    text = re.sub(r"[^0-9.\-]", "", text)
    if not text or text in ("-", ".", "-."):
        return 0.0
    try:
        return float(text)
    except ValueError:
        return 0.0


def text(value) -> str:
    if value is None or isinstance(value, (dict, list)):
        return ""
    return " ".join(str(value).split())


def first(obj, keys, depth: int = 0):
    if depth > 4:
        return None
    if isinstance(obj, dict):
        for key in keys:
            if key in obj:
                value = obj[key]
                if value is not None and value != "":
                    return value
        for key in ("transaction", "deposit", "detail", "data", "result", "item", "account"):
            value = obj.get(key)
            if isinstance(value, dict):
                found = first(value, keys, depth + 1)
                if found is not None:
                    return found
    return None


def find_list(obj, keys, depth: int = 0) -> list[dict]:
    if depth > 5:
        return []
    if isinstance(obj, list):
        return [item for item in obj if isinstance(item, dict)]
    if not isinstance(obj, dict):
        return []
    for key in keys:
        value = obj.get(key)
        if isinstance(value, list):
            rows = [item for item in value if isinstance(item, dict)]
            if rows:
                return rows
    for key in keys:
        value = obj.get(key)
        if isinstance(value, dict):
            rows = find_list(value, keys, depth + 1)
            if rows:
                return rows
    for value in obj.values():
        if isinstance(value, (dict, list)):
            rows = find_list(value, keys, depth + 1)
            if rows:
                return rows
    return []


def jalali_to_gregorian(year: int, month: int, day: int):
    year += 1595
    days = (
        -355668
        + (365 * year)
        + ((year // 33) * 8)
        + (((year % 33) + 3) // 4)
        + day
        + ((month - 1) * 31 if month < 7 else ((month - 7) * 30) + 186)
    )
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        days -= 1
        gy += 100 * (days // 36524)
        days %= 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    months = [0, 31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 1
    while gm <= 12 and gd > months[gm]:
        gd -= months[gm]
        gm += 1
    return gy, gm, gd


def parse_time(value) -> int:
    if value is None or isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)):
        stamp = float(value)
        if stamp > 10**17:
            return int((stamp - 621355968000000000) / 10000000)
        if stamp > 10**14:
            return int(stamp / 1000000)
        if stamp > 10**11:
            return int(stamp / 1000)
        if stamp > 10**8:
            return int(stamp)
        return 0
    raw = str(value).strip()
    if not raw:
        return 0
    if re.fullmatch(r"\d{10,19}", raw):
        return parse_time(int(raw))
    iso = raw.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(iso)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=TEHRAN)
        return int(parsed.timestamp())
    except ValueError:
        pass
    match = re.match(
        r"^(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?",
        raw,
    )
    if not match:
        return 0
    year, month, day = int(match.group(1)), int(match.group(2)), int(match.group(3))
    hour, minute, second = int(match.group(4) or 0), int(match.group(5) or 0), int(match.group(6) or 0)
    try:
        if 1200 <= year <= 1600:
            year, month, day = jalali_to_gregorian(year, month, day)
        parsed = datetime(year, month, day, hour, minute, second, tzinfo=TEHRAN)
        return int(parsed.timestamp())
    except (ValueError, OverflowError):
        return 0


def load_session() -> dict:
    with LOCK:
        try:
            with open(SESSION_PATH, "r", encoding="utf-8") as handle:
                data = json.load(handle)
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}


def save_session(data: dict) -> None:
    with LOCK:
        directory = os.path.dirname(SESSION_PATH) or "."
        os.makedirs(directory, exist_ok=True)
        fd, path = tempfile.mkstemp(prefix=".session.", dir=directory)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False)
            os.chmod(path, 0o600)
            os.replace(path, SESSION_PATH)
        finally:
            if os.path.exists(path):
                try:
                    os.unlink(path)
                except OSError:
                    pass


def api_error(response: requests.Response) -> str:
    try:
        data = response.json()
    except ValueError:
        data = None
    if isinstance(data, dict):
        for key in ("detail", "message", "error", "title", "errorMessage"):
            value = text(data.get(key))
            if value:
                return f"ویپاد: {value}"
    body = text(response.text)
    return f"ویپاد {response.status_code}: {clip(body, 180)}"


def http_error_status(code: int) -> int:
    if 400 <= code < 500:
        return code
    return 502


def api(method: str, path: str, data=None, auth=None, req_id=None, params=None, version=None):
    request_id = req_id or uuid.uuid4().hex
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "fa-IR",
        "Content-Type": "application/json",
        "User-Agent": UA,
        "X-Client-Version": version or CLIENT,
        "Referer": "https://web.wepod.ir/",
        "Request-Id": request_id,
        "Cache-Control": "no-cache",
    }
    if auth is not None:
        headers["Authorization"] = str(auth)
    try:
        response = requests.request(
            method,
            API_BASE + path.lstrip("/"),
            json=data if data is not None else None,
            headers=headers,
            params=params,
            proxies=PROXIES,
            timeout=TIMEOUT,
        )
    except requests.RequestException as exc:
        raise BankError("ارتباط با ویپاد برقرار نشد: " + clip(str(exc), 180))
    response_id = response.headers.get("request-id") or response.headers.get("Request-Id") or request_id
    if response.status_code >= 400:
        raise BankError(api_error(response), http_error_status(response.status_code))
    if not response.content:
        return None, response_id
    try:
        return response.json(), response_id
    except ValueError:
        raise BankError("پاسخ ویپاد خوانا نیست", 502)


def expiry(data, default: int = 900) -> int:
    now = int(time.time())
    token = data.get("token") if isinstance(data, dict) else None
    sources = [data, token] if isinstance(data, dict) else [data]
    for source in sources:
        if not isinstance(source, dict):
            continue
        for key in ("expiresIn", "expires_in"):
            value = source.get(key)
            if value is not None:
                try:
                    seconds = int(float(value))
                    if 0 < seconds < 10**6:
                        return now + seconds
                except (TypeError, ValueError):
                    pass
        for key in ("expiresAt", "expires_at"):
            value = source.get(key)
            if value is not None:
                stamp = parse_time(value)
                if stamp:
                    return stamp
    access = ""
    if isinstance(data, dict):
        access = text(data.get("accessToken"))
        if not access and isinstance(data.get("token"), dict):
            access = text(data["token"].get("accessToken"))
    if access.count(".") == 2:
        try:
            payload = access.split(".")[1]
            payload += "=" * (-len(payload) % 4)
            import base64

            claims = json.loads(base64.urlsafe_b64decode(payload))
            if claims.get("exp"):
                return int(claims["exp"])
        except (ValueError, TypeError, json.JSONDecodeError):
            pass
    return now + default


def access_token(data) -> str:
    if not isinstance(data, dict):
        return ""
    token = data.get("token")
    if isinstance(token, dict):
        value = token.get("accessToken") or token.get("access_token")
        if value:
            return str(value)
    return str(data.get("accessToken") or data.get("access_token") or "")


def id_token(data) -> str:
    if not isinstance(data, dict):
        return ""
    token = data.get("token")
    if isinstance(token, dict):
        value = token.get("idToken") or token.get("id_token")
        if value:
            return str(value)
    return str(data.get("idToken") or data.get("id_token") or "")


def code_from_url(url: str) -> str:
    if not url:
        return ""
    parsed = urlparse(url)
    for part in (parsed.query, parsed.fragment):
        values = parse_qs(part)
        for key in ("code", "authCode", "auth_code"):
            if values.get(key):
                return text(values[key][0])
    return ""


def token_from_action(url: str, device_key: str) -> str:
    code = code_from_url(url)
    if not code:
        try:
            session = requests.Session()
            response = session.get(
                url,
                headers={"User-Agent": UA, "Referer": "https://web.wepod.ir/"},
                proxies=PROXIES,
                timeout=TIMEOUT,
                allow_redirects=True,
            )
            log("action follow status=" + str(response.status_code) + " host=" + urlparse(response.url).netloc)
            code = code_from_url(response.url)
        except requests.RequestException as exc:
            log("action follow failed: " + clip(str(exc), 160))
    if not code:
        return ""
    data, _ = api(
        "POST",
        "oauth2/api/v4/token/getByAuthCode",
        {"authCode": code, "clientIssuer": CLIENT_ISSUER, "deviceKeyId": device_key},
        auth=None,
        version=CLIENT_NEW,
    )
    return access_token(data)


def browser_action(url: str, device_key: str) -> str:
    env = os.environ.copy()
    env["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/wipad-api/ms-playwright"
    env["HOME"] = "/tmp"
    try:
        result = subprocess.run(
            ["/opt/wipad-api/pw-venv/bin/python", "/opt/wipad-api/action_login.py"],
            input=json.dumps({"url": url}),
            text=True,
            capture_output=True,
            timeout=120,
            env=env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        log("browser action failed: " + clip(str(exc), 160))
        return ""
    try:
        payload = json.loads(result.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        log("browser action returned no code")
        return ""
    code = text(payload.get("code"))
    if not code:
        log("browser action returned no code")
        return ""
    data, _ = api(
        "POST",
        "oauth2/api/v4/token/getByAuthCode",
        {"authCode": code, "clientIssuer": CLIENT_ISSUER, "deviceKeyId": device_key},
        auth=None,
        version=CLIENT_NEW,
    )
    return access_token(data)


def refresh_token() -> str:
    with LOCK:
        session = load_session()
        current = text(session.get("accessToken"))
        if not current:
            raise AuthError("نشست ویپاد وجود ندارد؛ دوباره وارد شو")
        data, request_id = api(
            "POST",
            "oauth2/api/v4/token/refresh",
            {"accessToken": current},
            auth=current,
            req_id=text(session.get("requestId")) or None,
            version=CLIENT_NEW,
        )
        fresh = access_token(data)
        if not fresh:
            raise AuthError("ویپاد نشست را تازه نکرد؛ دوباره وارد شو")
        session["accessToken"] = fresh
        session["idToken"] = id_token(data) or text(session.get("idToken"))
        session["requestId"] = request_id
        session["expiresAt"] = expiry(data)
        key = first(data, ["keyId", "deviceKeyId"])
        if key:
            session["keyId"] = str(key)
        session["refreshedAt"] = int(time.time())
        save_session(session)
        return fresh


def ensure_token() -> str:
    session = load_session()
    current = text(session.get("accessToken"))
    if not current:
        raise AuthError("نشست ویپاد وجود ندارد؛ دوباره وارد شو")
    try:
        expires = float(session.get("expiresAt") or 0)
    except (TypeError, ValueError):
        expires = 0
    if expires > time.time() + 45:
        return current
    return refresh_token()


def start_login(phone: str, password: str = "") -> dict:
    number = norm_phone(phone)
    if len(number) < 10:
        raise BadInput("شماره موبایل ویپاد درست نیست")
    with LOCK:
        session = load_session()
        same = text(session.get("phone")) == number and text(session.get("apiBase")) == API_BASE
        if same:
            if text(session.get("accessToken")) and not session.get("pendingAt"):
                try:
                    if float(session.get("expiresAt") or 0) > time.time() + 45:
                        return {"ok": True, "otpRequired": False, "loggedIn": True}
                except (TypeError, ValueError):
                    pass
            pending = float(session.get("pendingAt") or 0)
            if pending and time.time() - pending < 110:
                return {"ok": True, "otpRequired": True, "pending": True}
        device_id = hashlib.md5((number + ":" + str(time.time())).encode()).hexdigest()
        body = {
            "deviceId": device_id,
            "deviceName": "Android Chrome",
            "mobileNumber": number,
            "latitude": "0",
            "longitude": "0",
            "osType": 4,
            "deviceType": 1,
            "osVersion": "unknown",
            "appVersion": APP_VERSION,
            "appName": "wepod-web",
            "clientIssuer": CLIENT_ISSUER,
            "flowType": FLOW_TYPE,
        }
        data, request_id = api(
            "POST",
            "oauth2/api/v4/auth/authorize",
            body,
            auth=None,
            version=CLIENT_NEW,
        )
        key = first(data, ["keyId", "deviceKeyId"])
        if not key:
            raise BankError("ویپاد کلید دستگاه نداد", 502)
        saved = {
            "phone": number,
            "deviceId": device_id,
            "keyId": str(key),
            "requestKey": request_id or "",
            "tempToken": "",
            "accessToken": "",
            "idToken": "",
            "expiresAt": 0,
            "pendingAt": int(time.time()),
            "createdAt": int(time.time()),
            "apiBase": API_BASE,
        }
        save_session(saved)
        log("login started phone=" + mask_phone(number))
        return {"ok": True, "otpRequired": True}


def verify_otp(code: str) -> dict:
    with LOCK:
        session = load_session()
        if text(session.get("accessToken")) and not session.get("pendingAt"):
            return {"ok": True, "loggedIn": True, "already": True}
        number = text(session.get("phone"))
        key = text(session.get("keyId"))
        if not number or not key:
            raise BadInput("ابتدا شماره را وارد کن تا کد فرستاده شود")
        otp = digits(code)
        if not otp:
            raise BadInput("کد پیامک لازم است")
        warm_id = text(session.get("requestKey")) or text(session.get("requestId")) or None
        body = {
            "deviceKeyId": key,
            "mobileNumber": number,
            "otpCode": otp,
            "clientIssuer": CLIENT_ISSUER,
            "flowType": FLOW_TYPE,
        }
        data, request_id = api(
            "POST",
            "oauth2/api/v4/auth/verify",
            body,
            auth=None,
            req_id=warm_id,
            version=CLIENT_NEW,
        )
        if isinstance(data, dict):
            log("verify response keys=" + ",".join(sorted(str(k) for k in data.keys())))
            tok = data.get("token")
            if isinstance(tok, dict):
                log("verify token keys=" + ",".join(sorted(str(k) for k in tok.keys())))
        action = data.get("actionUrl") if isinstance(data, dict) else None
        url = ""
        if isinstance(action, dict):
            url = text(action.get("url") or action.get("URL") or action.get("actionUrl"))
        elif action:
            url = text(action)
        token = ""
        if url:
            log("verify action host=" + urlparse(url).netloc + " query=" + ",".join(sorted(parse_qs(urlparse(url).query).keys())))
            token = token_from_action(url, key)
            if not token:
                token = browser_action(url, key)
        if not token:
            token = access_token(data)
        if not token:
            raise BankError("ویپاد توکن نداد", 502)
        session["accessToken"] = token
        session["idToken"] = id_token(data) or ""
        session["requestId"] = request_id
        session["expiresAt"] = expiry(data)
        session["pendingAt"] = 0
        session["verifiedAt"] = int(time.time())
        fresh_key = first(data, ["keyId", "deviceKeyId"])
        if fresh_key:
            session["keyId"] = str(fresh_key)
        save_session(session)
        log("login verified phone=" + mask_phone(number))
        return {"ok": True, "loggedIn": True}


def logout() -> dict:
    with LOCK:
        session = load_session()
        current = text(session.get("accessToken"))
        if current:
            for path in ("api/profile/terminateCurrentSession", "api/Profile/terminateCurrentSession"):
                try:
                    api("POST", path, {}, auth=current, req_id=text(session.get("requestId")) or None)
                    break
                except BankError:
                    continue
        save_session({})
        return {"ok": True}


def status() -> dict:
    session = load_session()
    number = text(session.get("phone"))
    out = {
        "ok": True,
        "loggedIn": False,
        "tokenFresh": False,
        "otpRequired": False,
        "profile": mask_phone(number) if number else "",
    }
    pending = float(session.get("pendingAt") or 0)
    if pending and time.time() - pending < 110:
        out["otpRequired"] = True
    if not text(session.get("accessToken")):
        return out
    out["loggedIn"] = True
    try:
        ensure_token()
        expires = float(load_session().get("expiresAt") or 0)
        out["tokenFresh"] = True
        out["expiresIn"] = max(0, int(expires - time.time()))
    except BankError as exc:
        out["loggedIn"] = False
        out["tokenFresh"] = False
        out["err"] = str(exc)
    return out


def get_accounts(token: str) -> list[dict]:
    paths = [
        "api/deposit/getCustomerAggregatedAccounts",
        "api/Deposit/getCustomerDeposits",
        "api/deposit/getAccountList",
    ]
    keys = ["accounts", "deposits", "accountList", "items", "data", "result", "records"]
    last_error = None
    for path in paths:
        try:
            data, _ = api("GET", path, auth=token, version=CLIENT_NEW)
            rows = find_list(data, keys)
            if rows:
                return rows
        except BankError as exc:
            last_error = exc
    if last_error:
        raise last_error
    return []


def account_number(account: dict) -> str:
    value = first(
        account,
        [
            "depositNumber",
            "depositNo",
            "deposit",
            "number",
            "accountNumber",
            "accountNo",
            "iban",
            "sheba",
            "cardNumber",
        ],
    )
    return digits(value)


def accounts_total(accounts: list[dict]) -> float:
    total = 0.0
    for account in accounts:
        value = 0.0
        for key in (
            "balance",
            "availableAmount",
            "actualAmount",
            "withdrawableAmount",
            "availableBalance",
            "available",
            "currentBalance",
            "totalBalance",
            "remainingBalance",
            "amount",
        ):
            candidate = num(first(account, [key]))
            if candidate:
                value = candidate
                break
        total += value * MULT
    return total


def record_balance_delta(total: float) -> float:
    with LOCK:
        session = load_session()
        try:
            last = float(session.get("lastBalance") or 0)
        except (TypeError, ValueError):
            last = 0.0
        now = int(time.time())
        if last <= 0:
            session["lastBalance"] = total
            save_session(session)
            return 0.0
        if total > last + 0.5:
            delta = total - last
            queue = [
                item
                for item in (session.get("depositQueue") or [])
                if isinstance(item, dict) and int(item.get("at") or 0) >= now - 4 * 3600
            ]
            queue.append(
                {
                    "id": "BAL" + str(now * 1000),
                    "amount": delta,
                    "at": now,
                    "description": "واریز شبا/حساب (تشخیص خودکار)",
                }
            )
            session["depositQueue"] = queue[-50:]
            session["lastBalance"] = total
            save_session(session)
            log("balance deposit detected amount=" + str(int(round(delta))))
            return delta
        if total > 0 and total < last - 0.5:
            session["lastBalance"] = total
            save_session(session)
        return 0.0


def balance_watch() -> None:
    while True:
        try:
            token = ensure_token()
            accounts = get_accounts(token)
            record_balance_delta(accounts_total(accounts))
        except Exception:
            pass
        time.sleep(5)


def raw_transactions(page: int, size: int) -> list[dict]:
    global OWNER_NAME
    token = ensure_token()
    try:
        accounts = get_accounts(token)
    except BankError:
        accounts = []
    OWNER_NAME = ""
    for account in accounts:
        owner = text(first(account, ["ownerName", "accountHolderName", "customerName"]))
        if owner:
            OWNER_NAME = owner
            break
    total = accounts_total(accounts)
    params = {"size": str(size), "offset": str(max(0, page - 1) * size)}
    keys = ["items", "transactions", "rows", "data", "result", "records", "list", "transactionList", "depositTransactions"]
    rows: list[dict] = []
    try:
        data, _ = api("GET", "api/Shaparak/transactionsReport", auth=token, params=params, version=CLIENT_NEW)
        rows = find_list(data, keys)
    except BankError:
        pass
    numbers = []
    for account in accounts:
        number = account_number(account)
        if number and number not in numbers:
            numbers.append(number)
    if not rows:
        seen = set()
        last_error = None
        for number in numbers[:20] or [None]:
            params = {"size": str(size), "offset": str(max(0, page - 1) * size)}
            if number:
                params["depositNumber"] = number
            try:
                data, _ = api("GET", "api/Deposit/getCustomerDepositTransactions", auth=token, params=params)
            except BankError as exc:
                last_error = exc
                continue
            for row in find_list(data, keys):
                marker = hashlib.sha1(json.dumps(row, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
                if marker in seen:
                    continue
                seen.add(marker)
                rows.append(row)
        if not rows and last_error:
            raise last_error
    session = load_session()
    now = int(time.time())
    cutoff = now - 4 * 3600
    queue = [
        item
        for item in (session.get("depositQueue") or [])
        if isinstance(item, dict) and int(item.get("at") or 0) >= cutoff
    ]
    if page == 1:
        for item in queue[-50:]:
            rows.insert(
                0,
                {
                    "receipt": text(item.get("id")) or "BAL" + str(item.get("at")),
                    "type": "دریافت از حساب",
                    "amount": num(item.get("amount")),
                    "credit": True,
                    "description": text(item.get("description")) or "واریز شبا/حساب (تشخیص خودکار)",
                    "transactionDate": int(item.get("at") or now),
                    "at": int(item.get("at") or now),
                    "card": "",
                },
            )
    if queue != (session.get("depositQueue") or []):
        session["depositQueue"] = queue
        save_session(session)
    return rows


def infer_credit(row: dict, amount: float) -> bool:
    for key in ("credit", "isCredit", "is_credit"):
        value = first(row, [key])
        if isinstance(value, bool):
            return value
    for key in ("creditAmount", "depositAmount", "incomingAmount"):
        if num(first(row, [key])) > 0:
            return True
    for key in ("debitAmount", "withdrawAmount", "outgoingAmount"):
        if num(first(row, [key])) > 0:
            return False
    owner = OWNER_NAME
    dest = text(first(row, ["destinationCardName", "destinationName", "toName"]))
    src = text(first(row, ["sourceCardName", "sourceName", "fromName"]))
    if owner and dest:
        return owner in dest
    if owner and src:
        return owner not in src
    labels = []
    for key in (
        "direction",
        "transactionDirection",
        "debitCredit",
        "creditDebit",
        "type",
        "transactionType",
        "transactionTypeName",
        "transactionTitle",
        "title",
        "operation",
        "description",
    ):
        value = text(first(row, [key]))
        if value:
            labels.append(value)
    joined = " ".join(labels)
    lowered = joined.lower()
    if any(word in joined for word in ("برداشت", "پرداخت", "بدهکار")) or any(
        word in lowered for word in ("debit", "withdraw", "outgoing", "out")
    ):
        return False
    if any(word in joined for word in ("واریز", "دریافت", "بستانکار")) or any(
        word in lowered for word in ("credit", "deposit", "receive", "incoming")
    ):
        return True
    return amount >= 0


def tx_amount(row: dict) -> float:
    for key in (
        "amount",
        "transactionAmount",
        "transferAmount",
        "depositAmount",
        "creditAmount",
        "debitAmount",
        "value",
        "price",
        "totalAmount",
    ):
        value = first(row, [key])
        if value is not None:
            number = num(value)
            if number:
                return number
    return 0.0


def tx_time(row: dict) -> int:
    for key in (
        "transactionDate",
        "transactionDateTime",
        "transactionTime",
        "createdAt",
        "createdDate",
        "dateTime",
        "issueDate",
        "date",
        "time",
        "persianDate",
        "transactionTime",
        "receiptTime",
        "at",
    ):
        value = first(row, [key])
        if value is not None:
            stamp = parse_time(value)
            if stamp:
                return stamp
    return 0


def tx_receipt(row: dict) -> str:
    for key in (
        "trackingNumber",
        "referenceNumber",
        "receiptNumber",
        "receipt",
        "transactionId",
        "traceNumber",
        "rrn",
        "documentNumber",
        "serialNumber",
        "transactionSerial",
        "id",
    ):
        value = text(first(row, [key]))
        if value:
            cleaned = digits(value) or value
            if cleaned:
                return cleaned
    return "W" + hashlib.sha1(
        json.dumps(row, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()[:20]


def tx_card(row: dict) -> str:
    for key in (
        "sourcePan",
        "sourceCardNumber",
        "sourceCard",
        "cardNumber",
        "payerCardNumber",
        "fromCard",
        "destinationPan",
        "destinationCardNumber",
        "destinationCard",
    ):
        value = digits(first(row, [key]))
        if len(value) >= 12:
            return value
    return ""


def tx_description(row: dict) -> str:
    parts = []
    for key in (
        "description",
        "transactionDescription",
        "title",
        "transactionTitle",
        "transactionTypeName",
        "destinationCardName",
        "transferFromDescription",
        "transferToDescription",
        "details",
        "note",
        "type",
    ):
        value = text(first(row, [key]))
        if value and value not in parts:
            parts.append(value)
    return clip(" · ".join(parts), 300)


def normalize(row: dict) -> dict:
    amount = tx_amount(row)
    credit = infer_credit(row, amount)
    original = tx_description(row)
    if credit:
        kind = "دریافت از سپرده" if "سپرده" in original else "دریافت از کارت"
    else:
        kind = "برداشت"
    return {
        "receipt": tx_receipt(row),
        "type": kind,
        "amount": int(round(abs(amount) * MULT)),
        "credit": bool(credit),
        "card": tx_card(row),
        "description": original,
        "at": tx_time(row),
    }


def transactions(page: int, size: int) -> list[dict]:
    rows = [normalize(row) for row in raw_transactions(page, size)]
    rows.sort(key=lambda row: row.get("at") or 0, reverse=True)
    return rows


def balance() -> dict:
    token = ensure_token()
    accounts = get_accounts(token)
    rows = []
    total = 0.0
    for account in accounts:
        value = 0.0
        for key in (
            "balance",
            "availableAmount",
            "actualAmount",
            "withdrawableAmount",
            "availableBalance",
            "available",
            "currentBalance",
            "totalBalance",
            "remainingBalance",
            "amount",
        ):
            candidate = num(first(account, [key]))
            if candidate:
                value = candidate
                break
        value *= MULT
        total += value
        rows.append(
            {
                "iban": text(first(account, ["iban", "sheba", "accountNumber", "depositNumber"])) or "",
                "total": str(int(round(value))),
                "name": text(first(account, ["ownerName", "name", "title", "accountName", "accountHolderName"])) or "",
            }
        )
    return {"currency": "IRR", "total": str(int(round(total))), "accounts": rows}


class Handler(BaseHTTPRequestHandler):
    server_version = "wipad-api"
    sys_version = ""

    def log_message(self, fmt, *args):
        log("%s %s" % (self.command, fmt % args))

    def send_json(self, code: int, payload) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return {}
        if length > 64 * 1024:
            raise BadInput("درخواست بیش از حد بزرگ است")
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except (ValueError, UnicodeDecodeError):
            raise BadInput("بدنه درخواست JSON نیست")

    def failure(self, exc: Exception) -> None:
        if isinstance(exc, BankError):
            code = exc.status
            message = str(exc)
        else:
            code = 500
            message = "خطای داخلی سرویس ویپاد"
            log("error " + repr(exc))
        self.send_json(code, {"ok": False, "error": message})

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        try:
            if parsed.path == "/health":
                self.send_json(200, {"ok": True, "service": "wipad-api", "version": "1"})
                return
            if parsed.path == "/status":
                self.send_json(200, status())
                return
            if parsed.path == "/debug/session":
                session = load_session()
                self.send_json(
                    200,
                    {
                        "ok": True,
                        "phone": mask_phone(text(session.get("phone"))),
                        "hasToken": bool(text(session.get("accessToken"))),
                        "expiresAt": session.get("expiresAt") or 0,
                        "pendingAt": session.get("pendingAt") or 0,
                        "hasKey": bool(text(session.get("keyId"))),
                    },
                )
                return
            if parsed.path == "/transactions":
                page = max(1, int(query.get("page", ["1"])[0]))
                size = min(200, max(1, int(query.get("size", ["50"])[0])))
                if query.get("raw", ["0"])[0] in ("1", "true", "yes"):
                    raw = raw_transactions(page, size)
                    self.send_json(200, {"items": [], "raw": raw})
                    return
                self.send_json(200, {"items": transactions(page, size)})
                return
            if parsed.path == "/balance":
                self.send_json(200, balance())
                return
            self.send_json(404, {"ok": False, "error": "مسیر پیدا نشد"})
        except Exception as exc:
            self.failure(exc)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/login":
                data = self.body()
                self.send_json(
                    200,
                    start_login(str(data.get("username") or data.get("phone") or ""), str(data.get("password") or "")),
                )
                return
            if parsed.path == "/otp":
                data = self.body()
                self.send_json(200, verify_otp(str(data.get("code") or "")))
                return
            if parsed.path == "/token":
                data = self.body()
                token = text(data.get("accessToken") or data.get("token"))
                if len(token) < 20:
                    raise BadInput("توکن ویپاد لازم است")
                with LOCK:
                    session = load_session()
                    session["accessToken"] = token
                    session["expiresAt"] = int(time.time()) + 3600
                    session["pendingAt"] = 0
                    session["verifiedAt"] = int(time.time())
                    session["apiBase"] = API_BASE
                    save_session(session)
                self.send_json(200, {"ok": True, "loggedIn": True})
                return
            if parsed.path == "/logout":
                self.send_json(200, logout())
                return
            self.send_json(404, {"ok": False, "error": "مسیر پیدا نشد"})
        except Exception as exc:
            self.failure(exc)


def main() -> None:
    directory = os.path.dirname(SESSION_PATH) or "."
    os.makedirs(directory, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    server.daemon_threads = True
    threading.Thread(target=balance_watch, daemon=True).start()
    log(
        "wipad-api listening=%d api=%s proxy=%s"
        % (PORT, API_BASE, "on" if PROXY else "off")
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
