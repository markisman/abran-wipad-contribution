#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sys
from urllib.parse import parse_qs, unquote, urlparse

from playwright.sync_api import sync_playwright


def code_from(url: str) -> str:
    if not url:
        return ""
    parsed = urlparse(url)
    for part in (parsed.query, parsed.fragment):
        values = parse_qs(part)
        for key in ("code", "authCode", "auth_code"):
            if values.get(key):
                return str(values[key][0])
    return ""


def proxy_config() -> dict | None:
    raw = (os.environ.get("WIPAD_PROXY") or os.environ.get("BLU_PROXY") or "").strip()
    if not raw:
        return None
    parsed = urlparse(raw)
    if not parsed.hostname:
        return None
    cfg = {"server": f"{parsed.scheme or 'http'}://{parsed.hostname}:{parsed.port or 80}"}
    if parsed.username:
        cfg["username"] = unquote(parsed.username)
    if parsed.password:
        cfg["password"] = unquote(parsed.password)
    return cfg


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        print(json.dumps({"error": "bad input"}))
        return 1
    url = str(payload.get("url") or "").strip()
    if not url:
        print(json.dumps({"error": "no url"}))
        return 1
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/wipad-api/ms-playwright")
    found = {"code": ""}

    def remember(value: str) -> None:
        if found["code"]:
            return
        code = code_from(value)
        if code:
            found["code"] = code

    with sync_playwright() as pw:
        browser = pw.chromium.launch(
            headless=True,
            proxy=proxy_config(),
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        try:
            context = browser.new_context(locale="fa-IR", ignore_https_errors=True)
            page = context.new_page()
            page.on("request", lambda request: remember(request.url))
            page.on("response", lambda response: remember(response.url))
            try:
                page.goto(url, wait_until="domcontentloaded", timeout=60000)
            except Exception:
                pass
            for _ in range(30):
                remember(page.url)
                if found["code"]:
                    break
                page.wait_for_timeout(1000)
        finally:
            browser.close()
    if found["code"]:
        print(json.dumps({"code": found["code"]}))
        return 0
    print(json.dumps({"error": "no code"}))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
